'use strict';

module.exports = function (gulp, PLUGIN, CONF) {
    gulp.task('default', ['build', 'webpack']);
};